<div class="row">
    <div class="col-sm-12">
        <h2>Tablas</h2>
        <table class="table table-hover table-condensed table-bordered">
            <caption>
                <button class="btn btn-primary"  data-toggle="modal" data-target="#modalNuevo">
                    Nuevo 
                    <span class="feather-plus"></span>
                </button>
            </caption>
            <tr>
                <td>Nombres</td>
                <td>Apellidos</td>
                <td>Email</td>
                <td>Telefonos</td>
                <td>Editar</td>
                <td>Eliminar</td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td>
                    <button class="btn btn-warning feather-edit-2" data-toggle="modal" data-target="#modalEdicion"></button>
                </td>
                <td>
                    <button class="btn btn-danger feather-trash-2"></button>
                
                </td>
            </tr>
        </table>
    </div>
</div>