
<div class="container">
    <div class="separator">   
        <div class="row">
            <div class="col-sm-2 title-group">Productos</div>
            <div class="col-sm-10 title-group">
                <input type="text" id="productinv" name="productinv" class="form-control form-control-sm" placeholder="Producto a buscar" required>
            </div>
        </div>
    </div>    

    <div id="product-list"></div>
</div>


<script type="text/javascript" src="../js/order-new.js"></script>
