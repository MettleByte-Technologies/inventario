<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
  <div id="title-content"><h2 ></h2></div>
  <div class="row">
    <div class="col-sm">
      <div class="alert alert-warning alert-dismissable" id="message">                    
      </div>
    </div>
  </div>

  <div id="content" >
    <div class="row">
      <div class="col-sm-3">
        <img src="../images/logo/crafbonlogo.png" style="width: 60%;">      
      </div>
      <div class="col-sm">
        <br/><br/><h2 >BIENVENIDOS</h2>
      </div>    
    </div>
    <div class="row">
      <div class="col-sm-3"></div>
      <div class="col-sm">
        <p>Esta es tu página corporativa para visualizar en línea: </p>
        <ul>
          <li>Inventario al instante</li>
          <li>Información del estado de los clientes</li>
          <li>Valores pendientes</li>
          <li>Cupos disponibles de los clientes</li>
        </ul>
        <p>Puedes ingresar pedidos en línea</p>
      </div>    
    </div>
  </div>
</main>
