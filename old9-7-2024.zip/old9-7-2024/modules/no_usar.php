    <div class="row">
        <div class="col-sm-12">
            <table id="tableProduct" class="hover" style="width:100%">
                <thead>
                    <tr>
                        <!--<th></th>-->
                        <th>Producto</th>
                        <th>Descripción</th>
                        <th>Cantidad</th>
                        <!--<th>Descuento</th>-->
                        <th>Precio</th>
                        <th>Stock</th>
                        <th>Imagen</th>
                    </tr>
                </thead>
                <tbody>
                                    <tr>
                        <!--<td scope="row">                        
                            <div >
                                <span class="d-inline-block" tabindex="0" data-toggle="tooltip" title="Editar">
                                    <input type="checkbox" name="9832" id="9832">
                                </span>
                            </div>
                        </td>-->
                        <td>9832  </td>
                        <td>BABARIA HYALURONIC ACID SERUM   </td>
                        <td><input type="text" id="_cantidad" value="0" /></td>
                        <!--<td>15                        -->
                        <!--<td>0  </td>-->
                        <td>11.84  </td>
                        <!--<td>11.84  </td>
                        <td>8.77  </td>-->
                        <!--<td>48-->
                        <td>47  </td>
                        <td>
                            
                                                            <img src="" alt="9832" style="width: 10%;"/>  
                                                        
                        </td>
                    </tr>                
                                </tbody>
            </table>
            
        </div>
    </div>
    <script type="text/javascript" src="../js/product.js"></script>