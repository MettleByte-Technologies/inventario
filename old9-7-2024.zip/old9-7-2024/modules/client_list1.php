<?php    
    $action = "select";
    include "../business/client.php";
?>
<div class="row">
    <div class="col-sm">        
            <table id="tableClient" class="display compact" width="100%"></table>            
        </div>
</div>
<script type="text/javascript" src="../js/client.js"></script>