<div class="row">
    <div class="input-group mb-3">
        <span class="input-group-text feather-users" id="basic-addon1"></span>
        <input type="text" id="client" name="client" class="form-control" placeholder="Nombres o Código" aria-label="Username" aria-describedby="basic-addon1">    
    </div>
</div>
<div class="row">
    <div class="col-sm-12">        
        <table id="example1" class="display compact" width="100%"></table>            
    </div>
</div>   


<input type="hidden" name="client-id" id="client-id" value="null">
<input type="hidden" name="order-id" id="order-id" value="null">

<script type="text/javascript" src="../js/functions.js"></script>
<script type="text/javascript" src="../js/order-new-client.js"></script>
