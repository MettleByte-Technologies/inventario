<?php
    /******************** init session ***********************/
    //ini_set('session.save_path', $_SERVER['DOCUMENT_ROOT'] . '/inventarios/session');
    session_start(); 
?>