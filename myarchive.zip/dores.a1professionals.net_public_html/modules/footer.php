<!-- begin footer -->
        <form name="refreshForm"> 
            <input type="hidden" name="visited" value="" /> 
        </form> 

        <!--<div class="text-center text-info footer" >&copy; 2006-2021</div>-->

        <script type="text/javascript" src="../js/jquery.js"></script>
        <script type="text/javascript" src="../bootstrap/js/bootstrap.js"></script>
        <script type="text/javascript" src="../js/sidebar.js"></script>
        <script type="text/javascript" src="../js/functions.js"></script>
        <script type="text/javascript" scr="../js/alertifyjs/alertify.js" ></script>
        <script type="text/javascript" src="../js/datatables.min.js"></script>
        <!--<script type="text/javascript" src="../DataTables/Buttons-2.2.2/js/buttons.bootstrap5.min.js"></script>-->
        



    </body>
</html>