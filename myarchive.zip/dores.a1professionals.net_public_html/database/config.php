<?php
return array(
    "driver"    =>"mysql",
    "host"      =>"localhost",
    "user"      =>"doresu",
    "pass"      =>"2jqlsUJr2jhf",
    "database"  =>"doresdb",
    "schema"    =>"",
    "charset"   =>"utf8"
);
