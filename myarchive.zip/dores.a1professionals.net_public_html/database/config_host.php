<?php
return array(
    "driver"    =>"mysql",
    "host"      =>"localhost",
    "user"      =>"crafb8si_admin",
    "pass"      =>"j2J-90rTTFKS",
    "database"  =>"crafb8si_magale",
    "schema"    =>"",
    "charset"   =>"utf8"
);
